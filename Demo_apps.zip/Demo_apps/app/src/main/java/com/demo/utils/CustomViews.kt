package com.ps.takitaki.uc

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView



val LIGHT = "light.ttf"
val BOLD = "bold.ttf"
val REGULAR = "regular.ttf"


class TextLight @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : AppCompatTextView(context, attrs, defStyleAttr) {
    init {
        typeface = MyTypeFace.get(context, LIGHT)
    }
}


class Text @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : AppCompatTextView(context, attrs, defStyleAttr) {
    init {
        typeface = MyTypeFace.get(context, REGULAR)

    }
}

class TextBold @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : AppCompatTextView(context, attrs, defStyleAttr) {
    init {
        typeface = MyTypeFace.get(context, BOLD)

    }
}



