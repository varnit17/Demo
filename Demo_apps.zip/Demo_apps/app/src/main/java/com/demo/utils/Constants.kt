package com.demo.utils

class Constants {

    companion object {
        val BASE_URL = "http://takitaki.promptsoftech.com/"
        val API_URL = BASE_URL+"api/"
    }
}