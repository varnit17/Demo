package com.demo.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import com.demo.BR
import com.demo.R
import com.demo.databinding.FragmentHomeBinding
import com.demo.model.Category
import com.demo.view.adapter.CommonAdapter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.ps.takitaki.api.interfaces.APIResponse
import org.json.JSONObject

class HomeFragment : BaseFragment() {

    lateinit var binding : FragmentHomeBinding
    private val catList = arrayListOf<Category>()
    lateinit var commonAdapter: CommonAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate<FragmentHomeBinding>(inflater, R.layout.fragment_home, container, false)

        binding.rv.setLayoutManager(GridLayoutManager(activity, 2))

        commonAdapter = object : CommonAdapter(this!!.activity!!, R.layout.raw_category, catList) {
            override fun onUpdateView(holder: CommonHolder, `object`: Any, pos: Int) {

                holder.binding.setVariable(BR.category, `object`)
                holder.binding.executePendingBindings()
                val view = holder.binding.root

            }
        }

        return binding.root
    }


    fun getData( ){

        val call = apiService.getCategory("token")

        postData(call,false, object : APIResponse {
            override fun onResponse(response: JSONObject?) {

                val data = response?.getJSONArray("categories")
                //  val imagePath = getStr(response!!,"imagePath")


                val cat = Gson().fromJson<List<Category>>(data.toString(), object :
                    TypeToken<List<Category>>() {

                }.type)



                /*  for (categories : Categories in cat){

                  }*/

                catList.addAll(cat)

                commonAdapter.notifyDataSetChanged()





            }

            override fun onFailure() {
            }


        })



    }

}