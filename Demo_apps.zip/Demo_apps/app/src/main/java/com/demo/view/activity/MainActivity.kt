package com.demo.view.activity

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.demo.R
import com.demo.databinding.ActivityMainBinding
import com.demo.view.fragment.HomeFragment
import com.google.android.material.navigation.NavigationView

class MainActivity : BaseActivity(), NavigationView.OnNavigationItemSelectedListener {


    lateinit var binding: ActivityMainBinding;
    lateinit var view: View


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView<ActivityMainBinding>(
            this,
            R.layout.activity_main
        )
        binding.toolbar.title = "Home"
        setSupportActionBar(binding.toolbar)
        var toggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_Close
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        view = binding.navView.getHeaderView(0)


        view.setOnClickListener(View.OnClickListener { v -> })


        binding.navView.menu.getItem(0).setChecked(true)
        binding.navView.setNavigationItemSelectedListener(this)

        displaySelectedScreen(R.id.nav_home)



    }

    private fun displaySelectedScreen(itemId: Int) {

        var fragment: Fragment? = null
        when (itemId) {

            R.id.nav_home -> {

                binding.toolbar.setTitle(R.string.app_name)
                    fragment = HomeFragment()

            }


            R.id.nav_account -> {
                binding.toolbar.setTitle(R.string.my_account)
                fragment = HomeFragment()
            }


        }

        //replacing the fragment
        if (fragment != null) {
            val ft = supportFragmentManager.beginTransaction()
            ft.replace(R.id.content_frame, fragment)
            //ft.commit();
            ft.commitAllowingStateLoss()
        }


        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        }

    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        displaySelectedScreen(item.itemId)
       return true
    }
}
