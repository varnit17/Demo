package com.demo.view.fragment

import android.content.Context
import android.content.res.Resources
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.View

import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.request.RequestOptions
import com.demo.R
import com.demo.api.client.ApiClient
import com.demo.utils.Pref
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.kaopiz.kprogresshud.KProgressHUD
import com.ps.takitaki.api.interfaces.APIResponse
import com.ps.takitaki.api.interfaces.ApiInterface
import com.ps.takitaki.utils.MyApplication
import org.json.JSONException

import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


abstract class BaseFragment : Fragment(){

    protected lateinit var res: Resources
    protected lateinit var pref: Pref
    protected lateinit var toast: Toast
    protected lateinit var requestOptions: RequestOptions
    protected lateinit var apiService: ApiInterface
    protected lateinit var  hud: KProgressHUD
    protected lateinit var myApp : MyApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        pref =  Pref.getInstance(this.activity!!)
        myApp = MyApplication.mInstance!!

        res = resources
        requestOptions = RequestOptions()
        requestOptions!!.placeholder(R.drawable.ic_launcher_background)
        requestOptions!!.error(R.drawable.ic_launcher_background)
        requestOptions!!.fallback(R.drawable.ic_launcher_background)
        apiService = ApiClient.client!!.create(ApiInterface::class.java)

        hud = KProgressHUD.create(activity!!)
            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
            .setCancellable(true)
            .setAnimationSpeed(2)
            .setDimAmount(0.5f)
    }




    fun getStr(obj: JSONObject, key: String): String {

        try {

            return if (!obj.has(key) || obj.isNull(key)) {
                ""
            } else {
                obj.optString(key, "")
            }
        } catch (e: Exception) {
            return ""
        }

    }

    fun getLng(obj: JSONObject, key: String): Long {

        try {

            return if (!obj.has(key) || obj.isNull(key)) {
                0
            } else {
                obj.optLong(key, 0)
            }
        } catch (e: Exception) {
            return 0
        }

    }

    fun getInt(obj: JSONObject, key: String): Int {

        try {
            return if (!obj.has(key) || obj.isNull(key)) {
                0
            } else {
                obj.optInt(key, 0)
            }
        } catch (e: Exception) {
            return 0
        }

    }

    fun getDouble(obj: JSONObject, key: String): Double {

        try {

            return if (!obj.has(key) || obj.isNull(key)) {
                0.0
            } else {
                obj.optInt(key, 0).toDouble()
            }
        } catch (e: Exception) {
            return 0.0
        }

    }

    fun onSnack(view: View, msg: String){
        val snack = Snackbar.make(view,msg, Snackbar.LENGTH_LONG)
        snack.show()
    }

    protected fun toast(msg: String) {
        if (toast != null)
            toast!!.cancel()

        toast = Toast.makeText(activity, msg, Toast.LENGTH_LONG)
        toast!!.show()

    }

    protected fun showDialog(context: Context?) {
        //  PSProgressDialog.show(context,"");
        hud?.show()

    }

    protected fun hideDialog() {
        if (hud != null && hud!!.isShowing) {
            hud!!.dismiss()
        }
        // PSProgressDialog.dismiss();
    }


    protected fun isEmail(s: String): Boolean {
        return if (android.util.Patterns.EMAIL_ADDRESS.matcher(s).matches())
            true
        else
            false
    }

    protected fun isEmpaty(s: String): Boolean {
        return if (s.isEmpty())
            true
        else
            false
    }

    fun isConnected(): Boolean {

        val cm = activity!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetworkInfo
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting
    }

    protected fun postData(call: Call<Any>, isMsg: Boolean, apiResponse: APIResponse) {
        if (!isConnected()) {
            toast(res.getString(R.string.no_network))
            return
        }

        showDialog(activity)

        call.enqueue(object : Callback<Any> {

            override fun onResponse(call: Call<Any>, response: Response<Any>) {

                hideDialog()
                var obj: JSONObject? = null
                try {
                    obj = JSONObject(Gson().toJson(response.body()))
                    if (obj.getInt("success")==1){
                        apiResponse.onResponse(obj.getJSONObject("data"))

                        if(isMsg){
                            toast(getStr(obj,"message"))
                        }
                    }else{
                        toast(getStr(obj,"message"))
                    }

                } catch (e: JSONException) {
                    apiResponse.onFailure()
                    e.printStackTrace()
                }


            }
            override fun onFailure(call: Call<Any>?, t: Throwable?) {
                hideDialog()
                apiResponse.onFailure()
            }

        });
    }








}