package com.demo.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding

import androidx.recyclerview.widget.RecyclerView
import kotlin.collections.ArrayList

abstract class CommonAdapter(val context: Context, val layoutId: Int, var arrayList: ArrayList<*>) : RecyclerView.Adapter<CommonAdapter.CommonHolder>() {


    fun setData(data: ArrayList<*>) {
        arrayList = data as ArrayList<in Any>
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommonHolder {
        return CommonHolder(DataBindingUtil.inflate(LayoutInflater.from(context), viewType, parent, false))
    }



    override fun onBindViewHolder(holder: CommonHolder, position: Int) {
        onUpdateView(holder, arrayList.get(position), position)
    }

    override fun getItemCount(): Int {
        return arrayList.size    }

    override fun getItemViewType(position: Int): Int {
        return layoutId
    }


    inner class CommonHolder(var binding: ViewDataBinding) : RecyclerView.ViewHolder(binding.root)

    abstract fun onUpdateView(holder: CommonHolder, `object`: Any, pos: Int)

}
