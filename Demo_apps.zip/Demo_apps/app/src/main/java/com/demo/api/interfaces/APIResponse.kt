package com.ps.takitaki.api.interfaces

import org.json.JSONObject

interface APIResponse {

     fun onResponse(response: JSONObject?)
     fun onFailure()
}