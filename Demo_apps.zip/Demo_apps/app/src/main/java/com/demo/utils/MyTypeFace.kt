package com.ps.takitaki.uc

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import java.util.*

object MyTypeFace {
    private val TAG = "Typefaces"
    private val cache = Hashtable<String, Typeface>()

    operator fun get(c: Context, assetPath: String): Typeface? {
        synchronized(cache) {
            if (!cache.containsKey(assetPath)) {
                try {
                    val t = Typeface.createFromAsset(
                        c.assets,
                        assetPath
                    )
                    cache[assetPath] = t
                } catch (e: Exception) {
                    Log.e(
                        TAG, "Could not get typeface '" + assetPath
                                + "' because " + e.message
                    )
                    return null
                }

            }
            return cache[assetPath]
        }
    }
}