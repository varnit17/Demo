package com.ps.takitaki.utils

import android.app.Application
import com.demo.utils.Pref
import com.google.gson.Gson

class MyApplication : Application(){


    companion object{

        var mInstance: MyApplication? = null

    }
    lateinit var pref: Pref


    override fun onCreate() {
        super.onCreate()
        mInstance = this
        pref = Pref.getInstance(this)

    }

    @Synchronized
    fun getInstance(): MyApplication? {
        return mInstance
    }


   /* fun setVariant(variant: Variant) {
        if (variant == null) {
            pref.setValue(Constants.PREF_VARIANT, "")

        } else {
            val gson = Gson()
            val json = gson.toJson(variant)
            pref.setValue(Constants.PREF_VARIANT, json)
        }

    }


    fun getVariant(): Variant? {
        val variant = pref.getStringValue(Constants.PREF_VARIANT, "")
        return if (variant == "") {
            null
        } else Gson().fromJson<Variant>(variant, Variant::class.java!!)
    }*/










}