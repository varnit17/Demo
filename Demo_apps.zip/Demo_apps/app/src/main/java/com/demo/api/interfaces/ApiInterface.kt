package com.ps.takitaki.api.interfaces

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {


    @FormUrlEncoded
    @POST("login")
    fun login(@Field("email") email: String, @Field("password") password: String, @Field("mobile") mobile: String, @Field("device_token") device_token: String?, @Field("device_type") device_type: Int): Call<Any>


    @POST("get_category")
    fun getCategory(@Header("Authorization") token: String): Call<Any>


    @Multipart
    @POST("update_user_profile")
     fun editProfile(
        @Header("Authorization") auth: String,
        @Part("user_id") id: RequestBody,
        @Part("name") name: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part file: MultipartBody.Part
    ): Call<Any>







}