package com.demo.api.client

import androidx.databinding.library.BuildConfig
import com.demo.utils.Constants
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit


object ApiClient {

    private  var retrofit: Retrofit? = null

    val client: Retrofit?
        get() {

            if (retrofit == null) {

                val httpClient = OkHttpClient.Builder()
                httpClient.readTimeout(3, TimeUnit.MINUTES)
                httpClient.writeTimeout(3, TimeUnit.MINUTES)

                if (BuildConfig.DEBUG) {
                    val logging = HttpLoggingInterceptor()
                    logging.level = HttpLoggingInterceptor.Level.BODY
                    httpClient.addInterceptor(logging)
                }


                retrofit = Retrofit.Builder()
                    .baseUrl(Constants.API_URL)
                    .client(httpClient.build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofit
        }

}